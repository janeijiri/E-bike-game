'use strict';

// All game text lives here. Edit it, no coding needed.
const DATA = {
  gear: [
    { id: 'helmet',  e: '⛑️', label: 'Bike helmet',  ok: true,  msg: 'Helmet on! It protects your head if you fall.' },
    { id: 'vest',    e: '🦺', label: 'Bright top',   ok: true,  msg: 'Bright tops help drivers spot you sooner.' },
    { id: 'shoes',   e: '👟', label: 'Closed shoes', ok: true,  msg: 'Closed shoes keep your feet safe on the pedals.' },
    { id: 'gloves',  e: '🧤', label: 'Gloves',       ok: true,  msg: 'Gloves protect your hands and improve your grip.' },
    { id: 'buds',    e: '🎧', label: 'Earbuds',      ok: false, msg: 'Earbuds block horns and engines. Keep your ears free.' },
    { id: 'flip',    e: '🩴', label: 'Flip-flops',   ok: false, msg: 'Flip-flops slip off pedals. Wear closed shoes.' },
    { id: 'scarf',   e: '🧣', label: 'Loose scarf',  ok: false, msg: 'Loose scarves can tangle in wheels. Tuck or skip them.' },
    { id: 'phone',   e: '📱', label: 'Phone',        ok: false, msg: 'Keep both hands on the bars. Stow your phone.' }
  ],
  checks: [
    { label: 'Squeeze the brakes',         part: 'brakes',  msg: 'Brakes should grip firmly before every ride.' },
    { label: 'Press the tyres',            part: 'tyres',   msg: 'Firm tyres grip better and resist flats.' },
    { label: 'Check battery is locked in', part: 'battery', msg: 'A secure, charged battery keeps power steady.' },
    { label: 'Test the lights',            part: 'lights',  msg: 'Working lights help others see you.' },
    { label: 'Ring the bell',              part: 'bell',    msg: "A bell warns walkers you're coming." },
    { label: "Skip the check, I'm late",   part: null,      msg: 'Skipping checks is risky. Two minutes prevents problems.' },
    { label: 'Remove brakes to go faster', part: null,      msg: 'Brakes keep you in control. Never remove them.' }
  ],
  hazards: [
    { e: '🚶', name: 'Pedestrian steps out', best: 'BRAKE',     msg: 'Brake early and give way to people.' },
    { e: '🚪', name: 'Car door opens',       best: 'SWERVE',    msg: 'Look back, then steer wide of car doors.' },
    { e: '🕳️', name: 'Pothole ahead',        best: 'SLOW DOWN', msg: "Slow down so bumps don't throw you off." },
    { e: '🛑', name: 'Stop sign',            best: 'BRAKE',     msg: 'Stop, look both ways, then go when clear.' },
    { e: '🐕', name: 'Dog runs out',         best: 'BRAKE',     msg: 'Brake smoothly and give animals lots of space.' },
    { e: '👫', name: 'Walkers ahead',        best: 'BELL',      msg: "Ring your bell to warn walkers you're passing." }
  ],
  fallbackTip: 'Helmet on, bike checked, eyes up.',
  remember: 'Helmet on, bike checked, eyes up, hands ready to brake.'
};
const MAX_SCORE = 4 * 10 + 5 * 10 + 8 * 15;

const W = 960, H = 540;
const C = { teal: 0x0b8a7c, yellow: 0xffc93c, coral: 0xe8472f, ink: 0x123047, white: 0xffffff, road: 0x5b6b78 };
const FONT = 'system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif';
const state = { score: 0, tips: [] };

function txt(s, x, y, str, size, color, extra) {
  return s.add.text(x, y, str, Object.assign({
    fontFamily: FONT, fontSize: size + 'px', fontStyle: 'bold',
    color: color || '#123047', align: 'center', resolution: 2
  }, extra || {})).setOrigin(0.5);
}

let audioCtx = null, muted = false;
function unlockAudio() {
  try {
    if (!audioCtx) { const A = window.AudioContext || window.webkitAudioContext; if (A) audioCtx = new A(); }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  } catch (e) { }
}
function tone(freq, secs, type) {
  if (muted || !audioCtx) return;
  try {
    const o = audioCtx.createOscillator(), g = audioCtx.createGain(), t = audioCtx.currentTime;
    o.type = type || 'sine'; o.frequency.value = freq;
    g.gain.setValueAtTime(0.12, t); g.gain.exponentialRampToValueAtTime(0.001, t + secs);
    o.connect(g); g.connect(audioCtx.destination); o.start(); o.stop(t + secs);
  } catch (e) { }
}
const sfx = {
  ok()  { tone(660, 0.12); setTimeout(() => tone(880, 0.14), 90); },
  bad() { tone(180, 0.25, 'sawtooth'); }
};

function go(scene, key) {
  if (scene.leaving) return;
  scene.leaving = true;
  scene.cameras.main.fadeOut(250, 18, 48, 71);
  scene.cameras.main.once('camerafadeoutcomplete', () => scene.scene.start(key));
}

function button(s, x, y, w, h, label, fill, onPress, size) {
  const g = s.add.graphics();
  g.fillStyle(fill, 1); g.fillRoundedRect(-w / 2, -h / 2, w, h, 16);
  const t = txt(s, 0, 0, label, size || 26, fill === C.yellow ? '#123047' : '#ffffff');
  const c = s.add.container(x, y, [g, t]).setSize(w, h).setInteractive({ useHandCursor: true });
  c.on('pointerdown', () => { unlockAudio(); onPress(); });
  c.on('pointerover', () => c.setScale(1.04));
  c.on('pointerout', () => c.setScale(1));
  return c;
}

function muteButton(s) {
  const t = txt(s, 0, 0, muted ? '🔇' : '🔊', 28);
  const c = s.add.container(920, 26, [t]).setSize(52, 52).setInteractive({ useHandCursor: true });
  c.on('pointerdown', () => { unlockAudio(); muted = !muted; t.setText(muted ? '🔇' : '🔊'); });
}

class Base extends Phaser.Scene {
  begin(round, ground) {
    this.leaving = false;
    this.cameras.main.fadeIn(250, 18, 48, 71);
    this.cameras.main.setBackgroundColor('#d8f0fa');
    if (ground !== false) this.add.rectangle(W / 2, H - 20, W, 40, 0x9ad4c9);
    txt(this, 20, 26, 'Round ' + round + ' of 3', 22).setOrigin(0, 0.5);
    this.scoreText = txt(this, 870, 26, 'Score ' + state.score, 22).setOrigin(1, 0.5);
    muteButton(this);
  }
  addScore(n) {
    state.score = Math.max(0, state.score + n);
    this.scoreText.setText('Score ' + state.score);
  }
  flash(x, y, color) {
    const c = this.add.circle(x, y, 40, color, 0.55).setDepth(15);
    this.tweens.add({ targets: c, scale: 2.6, alpha: 0, duration: 350, onComplete: () => c.destroy() });
  }
  showFeedback(ok, msg) {
    if (this.fb) { this.tweens.killTweensOf(this.fb); this.fb.destroy(); }
    const lines = msg.split('\n');
    const w = Math.min(920, Math.max.apply(null, lines.map(l => l.length)) * 12.5 + 90);
    const h = 44 + (lines.length - 1) * 28;
    const g = this.add.graphics();
    g.fillStyle(ok ? C.teal : C.coral, 1); g.fillRoundedRect(-w / 2, -h / 2, w, h, 22);
    const t = txt(this, 0, 0, (ok ? '✔ ' : '✖ ') + msg, 22, '#ffffff', { wordWrap: { width: w - 40 } });
    this.fb = this.add.container(W / 2, 86, [g, t]).setDepth(20).setAlpha(0);
    this.tweens.add({ targets: this.fb, alpha: 1, duration: 150 });
    this.tweens.add({ targets: this.fb, alpha: 0, delay: 2000, duration: 300 });
  }
  right(o, msg) {
    this.addScore(10); state.tips.push(msg); sfx.ok();
    this.flash(o.x, o.y, C.teal); this.showFeedback(true, msg);
    o.setVisible(false);
    this.time.delayedCall(100, () => o.destroy());
  }
  wrong(o, msg) {
    this.addScore(-5); sfx.bad();
    this.flash(o.x, o.y, C.coral); this.showFeedback(false, msg);
    this.tweens.add({ targets: o, x: o.x + 10, yoyo: true, repeat: 3, duration: 40, onComplete: () => this.snapBack(o) });
  }
  snapBack(o) {
    o.setScale(1);
    this.tweens.add({ targets: o, x: o.home.x, y: o.home.y, duration: 220, ease: 'Back.easeOut', onComplete: () => o.setDepth(1) });
  }
  enableDrag() {
    this.input.on('dragstart', (p, o) => o.setDepth(10).setScale(1.06));
    this.input.on('drag', (p, o, x, y) => { o.x = x; o.y = y; });
    this.input.on('dragend', (p, o, dropped) => { if (!dropped) this.snapBack(o); });
    this.input.on('drop', (p, o, zone) => this.onDrop(o, zone));
  }
  makeCard(x, y, w, h, top, label, info) {
    const g = this.add.graphics();
    g.fillStyle(C.white, 1); g.fillRoundedRect(-w / 2, -h / 2, w, h, 14);
    g.lineStyle(3, C.ink, 1); g.strokeRoundedRect(-w / 2, -h / 2, w, h, 14);
    const kids = [g];
    if (top) {
      kids.push(txt(this, 0, -h / 2 + 30, top, 34));
      kids.push(txt(this, 0, h / 2 - 24, label, 20, '#123047', { wordWrap: { width: w - 16 } }));
    } else {
      kids.push(txt(this, 0, 0, label, 20, '#123047', { wordWrap: { width: w - 20 } }));
    }
    const c = this.add.container(x, y, kids).setSize(w, h).setInteractive({ useHandCursor: true }).setDepth(1);
    this.input.setDraggable(c);
    c.home = { x, y }; c.info = info;
    return c;
  }
}

// BootScene: nothing to load (no external files), so go straight to the title.
class Boot extends Phaser.Scene {
  create() { this.scene.start('Title'); }
}

// TitleScene: name, goal and Start button.
class Title extends Phaser.Scene {
  create() {
    this.leaving = false;
    this.cameras.main.fadeIn(250, 18, 48, 71);
    this.cameras.main.setBackgroundColor('#d8f0fa');
    this.add.rectangle(W / 2, 470, W, 140, C.road);
    for (let i = 0; i < 8; i++) this.add.rectangle(60 + i * 125, 480, 70, 8, C.white);
    txt(this, W / 2, 120, '🚴', 90);
    txt(this, W / 2, 215, 'Ride Ready', 80, '#0b8a7c');
    txt(this, W / 2, 285, 'Gear up. Check your bike. React fast.', 28);
    button(this, W / 2, 370, 260, 76, 'Start', C.teal, () => {
      state.score = 0; state.tips = [];
      go(this, 'HowTo');
    }, 38);
    txt(this, W / 2, 500, 'An e-bike safety game for riders aged 11 to 17', 20, '#ffffff');
  }
}

// HowToScene: three icons - Drag, Drop, React.
class HowTo extends Phaser.Scene {
  create() {
    this.leaving = false;
    this.cameras.main.fadeIn(250, 18, 48, 71);
    this.cameras.main.setBackgroundColor('#d8f0fa');
    txt(this, W / 2, 70, 'How to play', 52);
    [['👆', 'Drag', 'Pick up a card'], ['🎯', 'Drop', 'Put it in the right spot'], ['⚡', 'React', 'Tap the best move fast']]
      .forEach((s, i) => {
        const x = 170 + i * 310;
        txt(this, x, 190, s[0], 80);
        txt(this, x, 270, s[1], 34, '#0b8a7c');
        txt(this, x, 315, s[2], 22);
      });
    txt(this, W / 2, 385, 'In Round 3, keys 1 to 4 work too.', 20);
    button(this, W / 2, 450, 280, 72, "Let's ride", C.teal, () => go(this, 'Round1'), 34);
  }
}

// Round 1 - Gear Up: drag the right gear onto the rider.
class Round1 extends Base {
  constructor() { super('Round1'); }
  create() {
    this.begin(1); this.enableDrag(); this.left = 4;
    const rx = 480, ry = 250;
    const area = this.add.graphics();
    area.lineStyle(3, C.teal, 0.8); area.strokeRoundedRect(rx - 120, ry - 130, 240, 330, 24);
    txt(this, rx, 470, 'Drop gear on the rider', 20);
    this.add.zone(rx, ry + 35, 240, 330).setRectangleDropZone(240, 330);
    this.add.ellipse(rx, ry + 168, 150, 22, 0x000000, 0.15);
    [-16, 16].forEach(d => this.add.rectangle(rx + d, ry + 95, 24, 110, C.ink));
    this.torso = this.add.rectangle(rx, ry + 5, 66, 100, 0x8a98a6);
    [-48, 48].forEach(d => this.add.rectangle(rx + d, ry + 10, 18, 92, 0x8a98a6));
    this.add.circle(rx, ry - 70, 26, 0xf2c28b);
    this.worn = {
      helmet: [txt(this, rx, ry - 92, '⛑️', 54)],
      shoes:  [txt(this, rx - 18, ry + 158, '👟', 34), txt(this, rx + 18, ry + 158, '👟', 34)],
      gloves: [txt(this, rx - 48, ry + 58, '🧤', 30), txt(this, rx + 48, ry + 58, '🧤', 30)]
    };
    Object.keys(this.worn).forEach(k => this.worn[k].forEach(o => o.setVisible(false)));
    const slots = [[95, 190], [255, 190], [95, 300], [255, 300], [705, 190], [865, 190], [705, 300], [865, 300]];
    Phaser.Utils.Array.Shuffle(DATA.gear.slice()).forEach((it, i) =>
      this.makeCard(slots[i][0], slots[i][1], 150, 96, it.e, it.label, it));
  }
  onDrop(o) {
    const it = o.info;
    if (!it.ok) { this.wrong(o, it.msg); return; }
    if (it.id === 'vest') this.torso.setFillStyle(C.yellow);
    else this.worn[it.id].forEach(g => g.setVisible(true));
    this.right(o, it.msg);
    if (--this.left === 0) this.time.delayedCall(1300, () => go(this, 'Round2'));
  }
}

// Round 2 - Bike Check: drag each check onto the matching bike part.
class Round2 extends Base {
  constructor() { super('Round2'); }
  create() {
    this.begin(2); this.enableDrag(); this.left = 5;
    const g = this.add.graphics();
    g.lineStyle(8, C.ink, 1); g.strokeCircle(620, 400, 62); g.strokeCircle(860, 400, 62);
    g.lineStyle(8, C.teal, 1); g.beginPath();
    g.moveTo(620, 400); g.lineTo(690, 295); g.lineTo(735, 400); g.lineTo(820, 295); g.lineTo(690, 295);
    g.moveTo(820, 295); g.lineTo(860, 400); g.moveTo(820, 295); g.lineTo(832, 250); g.strokePath();
    g.lineStyle(8, C.ink, 1); g.beginPath();
    g.moveTo(670, 283); g.lineTo(712, 283); g.moveTo(815, 250); g.lineTo(882, 250); g.strokePath();
    g.fillStyle(C.yellow, 1); g.fillRoundedRect(698, 322, 28, 52, 6); g.fillCircle(905, 300, 11);
    g.fillStyle(C.coral, 1); g.fillCircle(800, 250, 9);
    const spots = [
      { p: 'tyres',   x: 620, y: 400, r: 44, lx: 620, ly: 478, n: 'Tyres' },
      { p: 'tyres',   x: 860, y: 400, r: 44, lx: 860, ly: 478, n: 'Tyres' },
      { p: 'battery', x: 712, y: 348, r: 34, lx: 712, ly: 440, n: 'Battery' },
      { p: 'brakes',  x: 880, y: 222, r: 34, lx: 880, ly: 182, n: 'Brakes' },
      { p: 'bell',    x: 800, y: 222, r: 34, lx: 800, ly: 182, n: 'Bell' },
      { p: 'lights',  x: 915, y: 300, r: 34, lx: 918, ly: 345, n: 'Lights' }
    ];
    const rings = this.add.graphics();
    spots.forEach(s => {
      rings.fillStyle(C.teal, 0.15); rings.fillCircle(s.x, s.y, s.r);
      rings.lineStyle(3, C.teal, 0.9); rings.strokeCircle(s.x, s.y, s.r);
      txt(this, s.lx, s.ly, s.n, 20, '#123047', { backgroundColor: '#ffffff', padding: { x: 8, y: 3 } });
      this.add.zone(s.x, s.y, s.r * 2, s.r * 2).setCircleDropZone(s.r).setData('part', s.p);
    });
    const slots = [[125, 160], [355, 160], [125, 243], [355, 243], [125, 326], [355, 326], [125, 409], [355, 409]];
    Phaser.Utils.Array.Shuffle(DATA.checks.slice()).forEach((it, i) =>
      this.makeCard(slots[i][0], slots[i][1], 220, 76, null, it.label, it));
  }
  onDrop(o, zone) {
    const it = o.info;
    if (it.part && zone.getData('part') === it.part) {
      txt(this, zone.x, zone.y, '✔', 40, '#0b8a7c').setDepth(5);
      this.right(o, it.msg);
      if (--this.left === 0) this.time.delayedCall(1300, () => go(this, 'Round3'));
    } else {
      this.wrong(o, it.part ? 'Not that part. Try another spot on the bike.' : it.msg);
    }
  }
}

// Round 3 - Quick Reactions: pick the best move before the bar runs out.
class Round3 extends Base {
  constructor() { super('Round3'); }
  create() {
    this.begin(3, false);
    this.add.rectangle(W / 2, 320, W, 20, 0x8fd19e);
    this.add.rectangle(W / 2, 410, W, 150, C.road);
    this.dashes = [];
    for (let i = 0; i < 12; i++) this.dashes.push(this.add.rectangle(i * 120, 410, 60, 8, C.white));
    this.rider = txt(this, 200, 365, '🚴', 96);
    this.add.rectangle(W / 2, 108, 400, 16, C.white).setStrokeStyle(3, C.ink);
    this.bar = this.add.rectangle(280, 108, 400, 16, C.yellow).setOrigin(0, 0.5).setVisible(false);
    const acts = ['BRAKE', 'BELL', 'SWERVE', 'SLOW DOWN'];
    acts.forEach((a, i) => button(this, 150 + i * 220, 490, 200, 64, (i + 1) + ' ' + a, C.teal, () => this.answer(a), 24));
    const onKey = e => { const i = parseInt(e.key, 10) - 1; if (acts[i]) this.answer(acts[i]); };
    this.input.keyboard.on('keydown', onKey);
    this.events.once('shutdown', () => this.input.keyboard.off('keydown', onKey));
    const extra = Phaser.Utils.Array.Shuffle(DATA.hazards.slice()).slice(0, 2);
    this.queue = Phaser.Utils.Array.Shuffle(DATA.hazards.concat(extra));
    this.answered = true;
    this.time.delayedCall(700, () => this.nextHazard());
  }
  update(t, delta) {
    this.dashes.forEach(d => { d.x -= 0.4 * delta; if (d.x < -40) d.x += 1440; });
  }
  nextHazard() {
    if (!this.queue.length) { this.time.delayedCall(500, () => go(this, 'Results')); return; }
    this.h = this.queue.shift(); this.answered = false;
    this.hz = txt(this, 700, 365, this.h.e, 84).setScale(0);
    this.hName = txt(this, W / 2, 150, this.h.name + '!', 30);
    this.tweens.add({ targets: this.hz, scale: 1, duration: 200, ease: 'Back.easeOut' });
    this.bar.setVisible(true).setScale(1, 1);
    this.tweens.add({ targets: this.bar, scaleX: 0, duration: 2000, ease: 'Linear' });
    this.t0 = this.time.now;
    this.timeout = this.time.delayedCall(2000, () => this.answer(null));
  }
  answer(choice) {
    if (this.answered) return;
    this.answered = true;
    if (this.timeout) this.timeout.remove();
    this.tweens.killTweensOf(this.bar); this.bar.setVisible(false);
    const rt = this.time.now - this.t0, h = this.h;
    if (choice === h.best) {
      this.addScore(rt < 1000 ? 15 : 10); state.tips.push(h.msg); sfx.ok();
      this.showFeedback(true, (rt < 1000 ? 'Quick! ' : '') + h.msg);
    } else {
      sfx.bad();
      this.tweens.add({ targets: this.rider, angle: 12, yoyo: true, repeat: 2, duration: 90, onComplete: () => this.rider.setAngle(0) });
      this.showFeedback(false, (choice ? "Whoops, that would've been risky!" : "Too slow! That would've been risky!") + '\nBest move: ' + h.best + '. ' + h.msg);
    }
    const hz = this.hz, nm = this.hName;
    this.tweens.add({ targets: [hz, nm], alpha: 0, delay: 1400, duration: 300, onComplete: () => { hz.destroy(); nm.destroy(); } });
    this.time.delayedCall(2000, () => this.nextHazard());
  }
}

// ResultsScene: score, stars, tips the player got right.
class Results extends Phaser.Scene {
  create() {
    this.leaving = false;
    this.cameras.main.fadeIn(250, 18, 48, 71);
    this.cameras.main.setBackgroundColor('#d8f0fa');
    const pct = state.score / MAX_SCORE;
    const stars = pct >= 0.9 ? 3 : pct >= 0.7 ? 2 : 1;
    txt(this, W / 2, 50, 'Ride complete!', 48);
    txt(this, W / 2, 125, '★'.repeat(stars) + '☆'.repeat(3 - stars), 80, '#d99a00');
    txt(this, W / 2, 190, stars + ' of 3 stars  |  Score ' + state.score + ' of ' + MAX_SCORE, 30);
    let tips = Phaser.Utils.Array.Shuffle(Array.from(new Set(state.tips))).slice(0, 3);
    if (!tips.length) tips = [DATA.fallbackTip];
    txt(this, W / 2, 240, 'You nailed these:', 24, '#0b8a7c');
    tips.forEach((t, i) => txt(this, W / 2, 278 + i * 36, '✔ ' + t, 22));
    txt(this, W / 2, 410, 'Remember: ' + DATA.remember, 22, '#ffffff', { backgroundColor: '#0b8a7c', padding: { x: 16, y: 8 } });
    button(this, W / 2, 485, 280, 64, 'Play again', C.coral, () => go(this, 'Title'), 30);
  }
}

new Phaser.Game({
  type: Phaser.AUTO,
  parent: 'game',
  width: W,
  height: H,
  backgroundColor: '#d8f0fa',
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  input: { activePointers: 3 },
  disableContextMenu: true,
  scene: [Boot, Title, HowTo, Round1, Round2, Round3, Results]
});
