# Ride Ready

A short drag-and-drop e-bike safety game for riders aged 11 to 17, built with Phaser 3.

- Round 1: Gear Up (drag the right gear onto the rider)
- Round 2: Bike Check (drag each pre-ride check onto the bike part)
- Round 3: Quick Reactions (pick the best move before the timer runs out)

## Files
- `index.html` - page structure
- `style.css` - page styles
- `game.js` - game code (content text is in the `DATA` object at the top)

## Run locally
Open `index.html` in a browser. No build step.
